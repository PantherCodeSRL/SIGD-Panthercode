﻿namespace CapaPresentacion
{
    partial class FrmFixtures
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFixtures));
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pbMenu = new System.Windows.Forms.PictureBox();
            this.btnF = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.pbFix = new System.Windows.Forms.PictureBox();
            this.pbB = new System.Windows.Forms.PictureBox();
            this.pbF = new System.Windows.Forms.PictureBox();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnH = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.panelI = new System.Windows.Forms.Panel();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.label50 = new System.Windows.Forms.Label();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.label51 = new System.Windows.Forms.Label();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.label53 = new System.Windows.Forms.Label();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.label58 = new System.Windows.Forms.Label();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.lblFH = new System.Windows.Forms.Label();
            this.dgvProx = new System.Windows.Forms.DataGridView();
            this.dgvRes = new System.Windows.Forms.DataGridView();
            this.lblResultados = new System.Windows.Forms.Label();
            this.lblFixture = new System.Windows.Forms.Label();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panelI.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRes)).BeginInit();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SlateGray;
            this.panel4.Controls.Add(this.tableLayoutPanel2);
            this.panel4.Controls.Add(this.tableLayoutPanel1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(961, 55);
            this.panel4.TabIndex = 25;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 10;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 102F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tableLayoutPanel2.Controls.Add(this.pbMenu, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnF, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnB, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbFix, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbB, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbF, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnMenu, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnH, 8, 0);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox1, 7, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(550, 55);
            this.tableLayoutPanel2.TabIndex = 27;
            // 
            // pbMenu
            // 
            this.pbMenu.Image = global::CapaPresentacion.Properties.Resources.house_solid;
            this.pbMenu.Location = new System.Drawing.Point(54, 3);
            this.pbMenu.Name = "pbMenu";
            this.pbMenu.Size = new System.Drawing.Size(22, 49);
            this.pbMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbMenu.TabIndex = 16;
            this.pbMenu.TabStop = false;
            // 
            // btnF
            // 
            this.btnF.FlatAppearance.BorderSize = 0;
            this.btnF.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            this.btnF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF.Location = new System.Drawing.Point(336, 3);
            this.btnF.Name = "btnF";
            this.btnF.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.btnF.Size = new System.Drawing.Size(93, 49);
            this.btnF.TabIndex = 12;
            this.btnF.Text = "Fútbol";
            this.btnF.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF.UseVisualStyleBackColor = true;
            this.btnF.Click += new System.EventHandler(this.btnF_Click);
            // 
            // btnB
            // 
            this.btnB.FlatAppearance.BorderSize = 0;
            this.btnB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            this.btnB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB.Location = new System.Drawing.Point(209, 3);
            this.btnB.Name = "btnB";
            this.btnB.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.btnB.Size = new System.Drawing.Size(93, 49);
            this.btnB.TabIndex = 11;
            this.btnB.Text = "Básquetbol";
            this.btnB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB.UseVisualStyleBackColor = true;
            this.btnB.Click += new System.EventHandler(this.btnB_Click);
            // 
            // pbFix
            // 
            this.pbFix.Image = global::CapaPresentacion.Properties.Resources.calendar_regular;
            this.pbFix.Location = new System.Drawing.Point(3, 3);
            this.pbFix.Name = "pbFix";
            this.pbFix.Size = new System.Drawing.Size(45, 49);
            this.pbFix.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbFix.TabIndex = 13;
            this.pbFix.TabStop = false;
            // 
            // pbB
            // 
            this.pbB.Image = global::CapaPresentacion.Properties.Resources.basketball_solid;
            this.pbB.Location = new System.Drawing.Point(181, 3);
            this.pbB.Name = "pbB";
            this.pbB.Size = new System.Drawing.Size(22, 49);
            this.pbB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbB.TabIndex = 14;
            this.pbB.TabStop = false;
            // 
            // pbF
            // 
            this.pbF.Image = global::CapaPresentacion.Properties.Resources.futbol_solid;
            this.pbF.Location = new System.Drawing.Point(308, 3);
            this.pbF.Name = "pbF";
            this.pbF.Size = new System.Drawing.Size(22, 49);
            this.pbF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbF.TabIndex = 15;
            this.pbF.TabStop = false;
            // 
            // btnMenu
            // 
            this.btnMenu.FlatAppearance.BorderSize = 0;
            this.btnMenu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Location = new System.Drawing.Point(82, 3);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.btnMenu.Size = new System.Drawing.Size(93, 49);
            this.btnMenu.TabIndex = 11;
            this.btnMenu.Text = "Menú Principal";
            this.btnMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnH
            // 
            this.btnH.FlatAppearance.BorderSize = 0;
            this.btnH.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            this.btnH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnH.Location = new System.Drawing.Point(463, 3);
            this.btnH.Name = "btnH";
            this.btnH.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.btnH.Size = new System.Drawing.Size(93, 49);
            this.btnH.TabIndex = 18;
            this.btnH.Text = "Hándbol";
            this.btnH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnH.UseVisualStyleBackColor = true;
            this.btnH.Click += new System.EventHandler(this.btnH_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CapaPresentacion.Properties.Resources.file_svg_handball_icon_1167717;
            this.pictureBox1.Location = new System.Drawing.Point(438, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(19, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.Controls.Add(this.btnCerrar, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button5, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(902, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(59, 55);
            this.tableLayoutPanel1.TabIndex = 25;
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackgroundImage = global::CapaPresentacion.Properties.Resources.circle_xmark_solid;
            this.btnCerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.Location = new System.Drawing.Point(33, 6);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(20, 31);
            this.btnCerrar.TabIndex = 23;
            this.btnCerrar.TabStop = false;
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            this.btnCerrar.MouseEnter += new System.EventHandler(this.btnCerrar_MouseEnter);
            this.btnCerrar.MouseLeave += new System.EventHandler(this.btnCerrar_MouseLeave);
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::CapaPresentacion.Properties.Resources.minus_solid;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(3, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(20, 35);
            this.button5.TabIndex = 21;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // panelI
            // 
            this.panelI.AutoScrollMargin = new System.Drawing.Size(0, 80);
            this.panelI.BackColor = System.Drawing.Color.SlateGray;
            this.panelI.Controls.Add(this.pictureBox33);
            this.panelI.Controls.Add(this.label50);
            this.panelI.Controls.Add(this.pictureBox36);
            this.panelI.Controls.Add(this.label51);
            this.panelI.Controls.Add(this.pictureBox42);
            this.panelI.Controls.Add(this.label53);
            this.panelI.Controls.Add(this.pictureBox35);
            this.panelI.Controls.Add(this.label55);
            this.panelI.Controls.Add(this.label57);
            this.panelI.Controls.Add(this.pictureBox39);
            this.panelI.Controls.Add(this.label58);
            this.panelI.Controls.Add(this.pictureBox34);
            this.panelI.Controls.Add(this.label59);
            this.panelI.Controls.Add(this.label7);
            this.panelI.Controls.Add(this.label60);
            this.panelI.Controls.Add(this.label62);
            this.panelI.Controls.Add(this.label81);
            this.panelI.Controls.Add(this.pictureBox29);
            this.panelI.Controls.Add(this.label63);
            this.panelI.Controls.Add(this.label64);
            this.panelI.Controls.Add(this.label80);
            this.panelI.Controls.Add(this.pictureBox31);
            this.panelI.Controls.Add(this.label66);
            this.panelI.Controls.Add(this.label70);
            this.panelI.Controls.Add(this.label77);
            this.panelI.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelI.Location = new System.Drawing.Point(0, 55);
            this.panelI.Name = "panelI";
            this.panelI.Size = new System.Drawing.Size(0, 492);
            this.panelI.TabIndex = 112;
            // 
            // pictureBox33
            // 
            this.pictureBox33.Image = global::CapaPresentacion.Properties.Resources.shield_solid;
            this.pictureBox33.Location = new System.Drawing.Point(111, 220);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(64, 65);
            this.pictureBox33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox33.TabIndex = 1;
            this.pictureBox33.TabStop = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(210, 115);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(46, 15);
            this.label50.TabIndex = 0;
            this.label50.Text = "Fecha";
            // 
            // pictureBox36
            // 
            this.pictureBox36.Image = global::CapaPresentacion.Properties.Resources.shield_solid;
            this.pictureBox36.Location = new System.Drawing.Point(290, 336);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(64, 65);
            this.pictureBox36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox36.TabIndex = 1;
            this.pictureBox36.TabStop = false;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(201, 139);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(72, 15);
            this.label51.TabIndex = 0;
            this.label51.Text = "Resultado";
            // 
            // pictureBox42
            // 
            this.pictureBox42.Image = global::CapaPresentacion.Properties.Resources.shield_solid;
            this.pictureBox42.Location = new System.Drawing.Point(290, 452);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(64, 65);
            this.pictureBox42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox42.TabIndex = 1;
            this.pictureBox42.TabStop = false;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(118, 172);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(52, 15);
            this.label53.TabIndex = 0;
            this.label53.Text = "Equipo";
            // 
            // pictureBox35
            // 
            this.pictureBox35.Image = global::CapaPresentacion.Properties.Resources.shield_solid;
            this.pictureBox35.Location = new System.Drawing.Point(290, 220);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(64, 65);
            this.pictureBox35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox35.TabIndex = 1;
            this.pictureBox35.TabStop = false;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(210, 231);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(46, 15);
            this.label55.TabIndex = 0;
            this.label55.Text = "Fecha";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(210, 347);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(46, 15);
            this.label57.TabIndex = 0;
            this.label57.Text = "Fecha";
            // 
            // pictureBox39
            // 
            this.pictureBox39.Image = global::CapaPresentacion.Properties.Resources.shield_solid;
            this.pictureBox39.Location = new System.Drawing.Point(111, 452);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(64, 65);
            this.pictureBox39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox39.TabIndex = 1;
            this.pictureBox39.TabStop = false;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(201, 255);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(72, 15);
            this.label58.TabIndex = 0;
            this.label58.Text = "Resultado";
            // 
            // pictureBox34
            // 
            this.pictureBox34.Image = global::CapaPresentacion.Properties.Resources.shield_solid;
            this.pictureBox34.Location = new System.Drawing.Point(111, 336);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(64, 65);
            this.pictureBox34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox34.TabIndex = 1;
            this.pictureBox34.TabStop = false;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(297, 172);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(52, 15);
            this.label59.TabIndex = 0;
            this.label59.Text = "Equipo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(201, 491);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "Resultado";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(201, 371);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(72, 15);
            this.label60.TabIndex = 0;
            this.label60.Text = "Resultado";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(118, 288);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(52, 15);
            this.label62.TabIndex = 0;
            this.label62.Text = "Equipo";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(297, 404);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(52, 15);
            this.label81.TabIndex = 0;
            this.label81.Text = "Equipo";
            // 
            // pictureBox29
            // 
            this.pictureBox29.Image = global::CapaPresentacion.Properties.Resources.shield_solid;
            this.pictureBox29.Location = new System.Drawing.Point(111, 104);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(64, 65);
            this.pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox29.TabIndex = 1;
            this.pictureBox29.TabStop = false;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(118, 404);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(52, 15);
            this.label63.TabIndex = 0;
            this.label63.Text = "Equipo";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(297, 288);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(52, 15);
            this.label64.TabIndex = 0;
            this.label64.Text = "Equipo";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(297, 520);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(52, 15);
            this.label80.TabIndex = 0;
            this.label80.Text = "Equipo";
            // 
            // pictureBox31
            // 
            this.pictureBox31.Image = global::CapaPresentacion.Properties.Resources.shield_solid;
            this.pictureBox31.Location = new System.Drawing.Point(290, 104);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(64, 65);
            this.pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox31.TabIndex = 1;
            this.pictureBox31.TabStop = false;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(133, 40);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(144, 29);
            this.label66.TabIndex = 0;
            this.label66.Text = "Resultados";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(210, 463);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(46, 15);
            this.label70.TabIndex = 0;
            this.label70.Text = "Fecha";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(118, 520);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(52, 15);
            this.label77.TabIndex = 0;
            this.label77.Text = "Equipo";
            // 
            // lblFH
            // 
            this.lblFH.AutoSize = true;
            this.lblFH.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFH.Location = new System.Drawing.Point(382, 85);
            this.lblFH.Name = "lblFH";
            this.lblFH.Size = new System.Drawing.Size(211, 29);
            this.lblFH.TabIndex = 113;
            this.lblFH.Text = "Fixtures Hándbol";
            // 
            // dgvProx
            // 
            this.dgvProx.BackgroundColor = System.Drawing.Color.SlateGray;
            this.dgvProx.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProx.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvProx.Location = new System.Drawing.Point(492, 170);
            this.dgvProx.Name = "dgvProx";
            this.dgvProx.Size = new System.Drawing.Size(457, 363);
            this.dgvProx.TabIndex = 115;
            // 
            // dgvRes
            // 
            this.dgvRes.BackgroundColor = System.Drawing.Color.SlateGray;
            this.dgvRes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRes.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvRes.Location = new System.Drawing.Point(12, 170);
            this.dgvRes.Name = "dgvRes";
            this.dgvRes.Size = new System.Drawing.Size(457, 363);
            this.dgvRes.TabIndex = 116;
            // 
            // lblResultados
            // 
            this.lblResultados.AutoSize = true;
            this.lblResultados.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultados.Location = new System.Drawing.Point(12, 135);
            this.lblResultados.Name = "lblResultados";
            this.lblResultados.Size = new System.Drawing.Size(113, 24);
            this.lblResultados.TabIndex = 117;
            this.lblResultados.Text = "Resultados";
            // 
            // lblFixture
            // 
            this.lblFixture.AutoSize = true;
            this.lblFixture.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFixture.Location = new System.Drawing.Point(494, 136);
            this.lblFixture.Name = "lblFixture";
            this.lblFixture.Size = new System.Drawing.Size(163, 24);
            this.lblFixture.TabIndex = 118;
            this.lblFixture.Text = "Proximas fechas";
            // 
            // FrmFixtures
            // 
            this.AllowDrop = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScrollMargin = new System.Drawing.Size(0, 25);
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(961, 547);
            this.Controls.Add(this.lblFixture);
            this.Controls.Add(this.lblResultados);
            this.Controls.Add(this.dgvRes);
            this.Controls.Add(this.dgvProx);
            this.Controls.Add(this.lblFH);
            this.Controls.Add(this.panelI);
            this.Controls.Add(this.panel4);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FrmFixtures";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.TransparencyKey = System.Drawing.Color.Peru;
            this.Load += new System.EventHandler(this.FrmFixtures_Load);
            this.panel4.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panelI.ResumeLayout(false);
            this.panelI.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.PictureBox pbFix;
        private System.Windows.Forms.PictureBox pbMenu;
        private System.Windows.Forms.PictureBox pbB;
        private System.Windows.Forms.PictureBox pbF;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Panel panelI;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblFH;
        private System.Windows.Forms.DataGridView dgvProx;
        private System.Windows.Forms.DataGridView dgvRes;
        private System.Windows.Forms.Label lblResultados;
        private System.Windows.Forms.Label lblFixture;
        private System.Windows.Forms.Button btnH;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}


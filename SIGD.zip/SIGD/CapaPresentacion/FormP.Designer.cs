﻿namespace CapaPresentacion {     partial class FormP     {         /// <summary>         /// Variable del diseñador necesaria.         /// </summary>         private System.ComponentModel.IContainer components = null;          /// <summary>         /// Limpiar los recursos que se estén usando.         /// </summary>         /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>         protected override void Dispose(bool disposing)         {             if (disposing && (components != null))             {                 components.Dispose();             }             base.Dispose(disposing);         }          #region Código generado por el Diseñador de Windows Forms          /// <summary>         /// Método necesario para admitir el Diseñador. No se puede modificar         /// el contenido de este método con el editor de código.         /// </summary>         private void InitializeComponent()         {             System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormP));
            this.lblBienvenido = new System.Windows.Forms.Label();
            this.lblInvitado = new System.Windows.Forms.Label();
            this.lblEmpresa = new System.Windows.Forms.Label();
            this.lblIdioma = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panInferior = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblContactos = new System.Windows.Forms.Label();
            this.btnTraducir = new System.Windows.Forms.Button();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.btnInicioSesion = new System.Windows.Forms.Button();
            this.plSuperior = new System.Windows.Forms.Panel();
            this.tlpOpciones = new System.Windows.Forms.TableLayoutPanel();
            this.pbFix = new System.Windows.Forms.PictureBox();
            this.pbEquipos = new System.Windows.Forms.PictureBox();
            this.btnFixtures = new System.Windows.Forms.Button();
            this.btnJugadores = new System.Windows.Forms.Button();
            this.btnEquipos = new System.Windows.Forms.Button();
            this.pbJugadores = new System.Windows.Forms.PictureBox();
            this.pbAddUser = new System.Windows.Forms.PictureBox();
            this.btnAgregarUser = new System.Windows.Forms.Button();
            this.tlpHerramientas = new System.Windows.Forms.TableLayoutPanel();
            this.pbLogin = new System.Windows.Forms.PictureBox();
            this.btnMin = new System.Windows.Forms.Button();
            this.flpFix = new System.Windows.Forms.FlowLayoutPanel();
            this.btnF = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnH = new System.Windows.Forms.Button();
            this.flpUsuarios = new System.Windows.Forms.FlowLayoutPanel();
            this.btnA = new System.Windows.Forms.Button();
            this.btnM = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.panInferior.SuspendLayout();
            this.plSuperior.SuspendLayout();
            this.tlpOpciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEquipos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJugadores)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddUser)).BeginInit();
            this.tlpHerramientas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogin)).BeginInit();
            this.flpFix.SuspendLayout();
            this.flpUsuarios.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBienvenido
            // 
            resources.ApplyResources(this.lblBienvenido, "lblBienvenido");
            this.lblBienvenido.BackColor = System.Drawing.SystemColors.GrayText;
            this.lblBienvenido.Name = "lblBienvenido";
            // 
            // lblInvitado
            // 
            resources.ApplyResources(this.lblInvitado, "lblInvitado");
            this.lblInvitado.BackColor = System.Drawing.SystemColors.GrayText;
            this.lblInvitado.Name = "lblInvitado";
            // 
            // lblEmpresa
            // 
            resources.ApplyResources(this.lblEmpresa, "lblEmpresa");
            this.lblEmpresa.BackColor = System.Drawing.Color.Transparent;
            this.lblEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblEmpresa.Name = "lblEmpresa";
            // 
            // lblIdioma
            // 
            this.lblIdioma.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.lblIdioma, "lblIdioma");
            this.lblIdioma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblIdioma.Name = "lblIdioma";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.BackColor = System.Drawing.Color.SlateGray;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Name = "label6";
            // 
            // panInferior
            // 
            this.panInferior.BackColor = System.Drawing.Color.SlateGray;
            this.panInferior.BackgroundImage = global::CapaPresentacion.Properties.Resources.degradou1;
            resources.ApplyResources(this.panInferior, "panInferior");
            this.panInferior.Controls.Add(this.label5);
            this.panInferior.Controls.Add(this.label2);
            this.panInferior.Controls.Add(this.label8);
            this.panInferior.Controls.Add(this.lblContactos);
            this.panInferior.Controls.Add(this.btnTraducir);
            this.panInferior.Controls.Add(this.lblIdioma);
            this.panInferior.Controls.Add(this.lblEmpresa);
            this.panInferior.Name = "panInferior";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Name = "label5";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Name = "label2";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // lblContactos
            // 
            this.lblContactos.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.lblContactos, "lblContactos");
            this.lblContactos.Name = "lblContactos";
            // 
            // btnTraducir
            // 
            this.btnTraducir.BackColor = System.Drawing.Color.SlateGray;
            this.btnTraducir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTraducir.FlatAppearance.BorderSize = 0;
            this.btnTraducir.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.btnTraducir, "btnTraducir");
            this.btnTraducir.Name = "btnTraducir";
            this.btnTraducir.TabStop = false;
            this.btnTraducir.UseVisualStyleBackColor = false;
            this.btnTraducir.Click += new System.EventHandler(this.btnTraducir_click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackgroundImage = global::CapaPresentacion.Properties.Resources.circle_xmark_solid;
            resources.ApplyResources(this.btnCerrar, "btnCerrar");
            this.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.TabStop = false;
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            this.btnCerrar.MouseEnter += new System.EventHandler(this.btnCerrar_MouseEnter);
            this.btnCerrar.MouseLeave += new System.EventHandler(this.btnCerrar_MouseLeave);
            // 
            // btnInicioSesion
            // 
            this.btnInicioSesion.BackColor = System.Drawing.Color.SlateGray;
            this.btnInicioSesion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInicioSesion.FlatAppearance.BorderSize = 0;
            this.btnInicioSesion.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnInicioSesion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnInicioSesion, "btnInicioSesion");
            this.btnInicioSesion.ForeColor = System.Drawing.Color.Black;
            this.btnInicioSesion.Name = "btnInicioSesion";
            this.btnInicioSesion.TabStop = false;
            this.btnInicioSesion.UseVisualStyleBackColor = false;
            this.btnInicioSesion.Click += new System.EventHandler(this.btnInicioSesion_Click);
            // 
            // plSuperior
            // 
            this.plSuperior.BackColor = System.Drawing.Color.SlateGray;
            this.plSuperior.Controls.Add(this.tlpOpciones);
            this.plSuperior.Controls.Add(this.tlpHerramientas);
            resources.ApplyResources(this.plSuperior, "plSuperior");
            this.plSuperior.Name = "plSuperior";
            // 
            // tlpOpciones
            // 
            resources.ApplyResources(this.tlpOpciones, "tlpOpciones");
            this.tlpOpciones.Controls.Add(this.pbFix, 5, 0);
            this.tlpOpciones.Controls.Add(this.pbEquipos, 3, 0);
            this.tlpOpciones.Controls.Add(this.btnFixtures, 6, 0);
            this.tlpOpciones.Controls.Add(this.btnJugadores, 2, 0);
            this.tlpOpciones.Controls.Add(this.btnEquipos, 4, 0);
            this.tlpOpciones.Controls.Add(this.pbJugadores, 1, 0);
            this.tlpOpciones.Controls.Add(this.pbAddUser, 7, 0);
            this.tlpOpciones.Controls.Add(this.btnAgregarUser, 8, 0);
            this.tlpOpciones.Name = "tlpOpciones";
            // 
            // pbFix
            // 
            this.pbFix.Image = global::CapaPresentacion.Properties.Resources.calendar_regular;
            resources.ApplyResources(this.pbFix, "pbFix");
            this.pbFix.Name = "pbFix";
            this.pbFix.TabStop = false;
            // 
            // pbEquipos
            // 
            this.pbEquipos.Image = global::CapaPresentacion.Properties.Resources.people_group_solid;
            resources.ApplyResources(this.pbEquipos, "pbEquipos");
            this.pbEquipos.Name = "pbEquipos";
            this.pbEquipos.TabStop = false;
            // 
            // btnFixtures
            // 
            this.btnFixtures.BackColor = System.Drawing.Color.SlateGray;
            this.btnFixtures.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFixtures.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnFixtures.FlatAppearance.BorderSize = 0;
            this.btnFixtures.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnFixtures.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnFixtures.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnFixtures, "btnFixtures");
            this.btnFixtures.Name = "btnFixtures";
            this.btnFixtures.TabStop = false;
            this.btnFixtures.UseVisualStyleBackColor = false;
            this.btnFixtures.Click += new System.EventHandler(this.btnFixtures_Click);
            // 
            // btnJugadores
            // 
            this.btnJugadores.BackColor = System.Drawing.Color.SlateGray;
            this.btnJugadores.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJugadores.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnJugadores.FlatAppearance.BorderSize = 0;
            this.btnJugadores.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnJugadores.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnJugadores.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnJugadores, "btnJugadores");
            this.btnJugadores.Name = "btnJugadores";
            this.btnJugadores.TabStop = false;
            this.btnJugadores.UseVisualStyleBackColor = false;
            this.btnJugadores.Click += new System.EventHandler(this.btnJugadores_Click);
            // 
            // btnEquipos
            // 
            this.btnEquipos.BackColor = System.Drawing.Color.SlateGray;
            this.btnEquipos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEquipos.FlatAppearance.BorderSize = 0;
            this.btnEquipos.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnEquipos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnEquipos, "btnEquipos");
            this.btnEquipos.ForeColor = System.Drawing.Color.Black;
            this.btnEquipos.Name = "btnEquipos";
            this.btnEquipos.TabStop = false;
            this.btnEquipos.UseVisualStyleBackColor = false;
            this.btnEquipos.Click += new System.EventHandler(this.btnEquipos_Click);
            // 
            // pbJugadores
            // 
            this.pbJugadores.Image = global::CapaPresentacion.Properties.Resources.person_running_solid;
            resources.ApplyResources(this.pbJugadores, "pbJugadores");
            this.pbJugadores.Name = "pbJugadores";
            this.pbJugadores.TabStop = false;
            // 
            // pbAddUser
            // 
            this.pbAddUser.Image = global::CapaPresentacion.Properties.Resources.user_plus_solid;
            resources.ApplyResources(this.pbAddUser, "pbAddUser");
            this.pbAddUser.Name = "pbAddUser";
            this.pbAddUser.TabStop = false;
            // 
            // btnAgregarUser
            // 
            this.btnAgregarUser.BackColor = System.Drawing.Color.SlateGray;
            this.btnAgregarUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgregarUser.FlatAppearance.BorderSize = 0;
            this.btnAgregarUser.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnAgregarUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnAgregarUser, "btnAgregarUser");
            this.btnAgregarUser.ForeColor = System.Drawing.Color.Black;
            this.btnAgregarUser.Name = "btnAgregarUser";
            this.btnAgregarUser.TabStop = false;
            this.btnAgregarUser.UseVisualStyleBackColor = false;
            this.btnAgregarUser.Click += new System.EventHandler(this.btnAgregarUser_Click);
            // 
            // tlpHerramientas
            // 
            resources.ApplyResources(this.tlpHerramientas, "tlpHerramientas");
            this.tlpHerramientas.Controls.Add(this.pbLogin, 0, 0);
            this.tlpHerramientas.Controls.Add(this.btnInicioSesion, 1, 0);
            this.tlpHerramientas.Controls.Add(this.btnMin, 2, 0);
            this.tlpHerramientas.Controls.Add(this.btnCerrar, 3, 0);
            this.tlpHerramientas.Name = "tlpHerramientas";
            // 
            // pbLogin
            // 
            this.pbLogin.BackColor = System.Drawing.Color.SlateGray;
            this.pbLogin.ErrorImage = global::CapaPresentacion.Properties.Resources.user_regular_blue;
            this.pbLogin.Image = global::CapaPresentacion.Properties.Resources.user_regular_blue;
            resources.ApplyResources(this.pbLogin, "pbLogin");
            this.pbLogin.Name = "pbLogin";
            this.pbLogin.TabStop = false;
            // 
            // btnMin
            // 
            this.btnMin.BackgroundImage = global::CapaPresentacion.Properties.Resources.minus_solid;
            resources.ApplyResources(this.btnMin, "btnMin");
            this.btnMin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMin.FlatAppearance.BorderSize = 0;
            this.btnMin.Name = "btnMin";
            this.btnMin.TabStop = false;
            this.btnMin.UseVisualStyleBackColor = true;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // flpFix
            // 
            this.flpFix.BackColor = System.Drawing.Color.SlateGray;
            this.flpFix.Controls.Add(this.btnF);
            this.flpFix.Controls.Add(this.btnB);
            this.flpFix.Controls.Add(this.btnH);
            resources.ApplyResources(this.flpFix, "flpFix");
            this.flpFix.Name = "flpFix";
            // 
            // btnF
            // 
            this.btnF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnF.FlatAppearance.BorderSize = 0;
            this.btnF.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnF, "btnF");
            this.btnF.Name = "btnF";
            this.btnF.TabStop = false;
            this.btnF.UseVisualStyleBackColor = true;
            this.btnF.Click += new System.EventHandler(this.btnF_Click);
            // 
            // btnB
            // 
            this.btnB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnB.FlatAppearance.BorderSize = 0;
            this.btnB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnB, "btnB");
            this.btnB.Name = "btnB";
            this.btnB.TabStop = false;
            this.btnB.UseVisualStyleBackColor = true;
            this.btnB.Click += new System.EventHandler(this.btnB_Click);
            // 
            // btnH
            // 
            this.btnH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnH.FlatAppearance.BorderSize = 0;
            this.btnH.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnH, "btnH");
            this.btnH.Name = "btnH";
            this.btnH.TabStop = false;
            this.btnH.UseVisualStyleBackColor = true;
            this.btnH.Click += new System.EventHandler(this.btnH_Click);
            // 
            // flpUsuarios
            // 
            this.flpUsuarios.BackColor = System.Drawing.Color.SlateGray;
            this.flpUsuarios.Controls.Add(this.btnA);
            this.flpUsuarios.Controls.Add(this.btnM);
            this.flpUsuarios.Controls.Add(this.btnE);
            resources.ApplyResources(this.flpUsuarios, "flpUsuarios");
            this.flpUsuarios.Name = "flpUsuarios";
            // 
            // btnA
            // 
            this.btnA.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnA.FlatAppearance.BorderSize = 0;
            this.btnA.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnA, "btnA");
            this.btnA.Name = "btnA";
            this.btnA.TabStop = false;
            this.btnA.UseVisualStyleBackColor = true;
            this.btnA.Click += new System.EventHandler(this.btnA_Click);
            // 
            // btnM
            // 
            this.btnM.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnM.FlatAppearance.BorderSize = 0;
            this.btnM.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnM, "btnM");
            this.btnM.Name = "btnM";
            this.btnM.TabStop = false;
            this.btnM.UseVisualStyleBackColor = true;
            this.btnM.Click += new System.EventHandler(this.btnM_Click);
            // 
            // btnE
            // 
            this.btnE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnE.FlatAppearance.BorderSize = 0;
            this.btnE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            resources.ApplyResources(this.btnE, "btnE");
            this.btnE.Name = "btnE";
            this.btnE.TabStop = false;
            this.btnE.UseVisualStyleBackColor = true;
            this.btnE.Click += new System.EventHandler(this.btnE_Click);
            // 
            // FormP
            // 
            this.AllowDrop = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.BackgroundImage = global::CapaPresentacion.Properties.Resources.Sin_título_6;
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.plSuperior);
            this.Controls.Add(this.flpFix);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.flpUsuarios);
            this.Controls.Add(this.lblInvitado);
            this.Controls.Add(this.lblBienvenido);
            this.Controls.Add(this.panInferior);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormP";
            this.TransparencyKey = System.Drawing.Color.Peru;
            this.Activated += new System.EventHandler(this.FormP_Activated);
            this.Load += new System.EventHandler(this.FormP_Load);
            this.panInferior.ResumeLayout(false);
            this.panInferior.PerformLayout();
            this.plSuperior.ResumeLayout(false);
            this.tlpOpciones.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbFix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEquipos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJugadores)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddUser)).EndInit();
            this.tlpHerramientas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbLogin)).EndInit();
            this.flpFix.ResumeLayout(false);
            this.flpUsuarios.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }          #endregion         private System.Windows.Forms.Label lblBienvenido;         private System.Windows.Forms.Label lblEmpresa;         private System.Windows.Forms.Label lblIdioma;         private System.Windows.Forms.Label label6;         private System.Windows.Forms.Panel panInferior;         private System.Windows.Forms.Button btnCerrar;         private System.Windows.Forms.Panel plSuperior;         private System.Windows.Forms.TableLayoutPanel tlpHerramientas;         private System.Windows.Forms.PictureBox pbLogin;         private System.Windows.Forms.Button btnMin;         private System.Windows.Forms.TableLayoutPanel tlpOpciones;         private System.Windows.Forms.PictureBox pbFix;         private System.Windows.Forms.PictureBox pbEquipos;         private System.Windows.Forms.Button btnFixtures;         private System.Windows.Forms.Button btnJugadores;         private System.Windows.Forms.Button btnEquipos;         private System.Windows.Forms.PictureBox pbJugadores;         private System.Windows.Forms.Button btnTraducir;         private System.Windows.Forms.FlowLayoutPanel flpFix;         private System.Windows.Forms.Button btnH;         private System.Windows.Forms.Button btnF;         private System.Windows.Forms.Button btnB;         public System.Windows.Forms.Button btnInicioSesion;         private System.Windows.Forms.Label lblContactos;         private System.Windows.Forms.Label label5;         private System.Windows.Forms.Label label2;         private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblInvitado;
        private System.Windows.Forms.PictureBox pbAddUser;
        private System.Windows.Forms.Button btnAgregarUser;
        private System.Windows.Forms.FlowLayoutPanel flpUsuarios;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btnM;
        private System.Windows.Forms.Button btnE;
    } }  